package com.yash.factory;

import com.yash.helperClass.CodingBookHelper;
import com.yash.helperClass.HorrorBookHelper;
import com.yash.helperClass.MySteryBookHelper;
import com.yash.helperClass.RomanticBookHelper;
import com.yash.ifactory.iBookCategory;

public class BookFactory {

	public static iBookCategory getInstance(String type) {
		String Type = type.toUpperCase();
		switch (Type) {
		case "CODING":
			return new CodingBookHelper();
		case "HORROR":
			return new HorrorBookHelper();
		case "MYSTERY":
			return new MySteryBookHelper();
		case "ROMANTIC":
			return new RomanticBookHelper();

		}
		return null;
	}
}
