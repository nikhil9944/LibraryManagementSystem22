package com.yash.helperClass;

import com.yash.ifactory.iBookCategory;
import com.yash.library.model.Book;

public class MySteryBookHelper implements iBookCategory {

	@Override
	public Book getBookNames(int bookId) {
		// TODO Auto-generated method stub
		return null;
	}

}
