package com.yash.Test;

import com.yash.factory.BookFactory;
import com.yash.library.model.Book;

public class BookTest {
	public static void main(String[] args) {
		Book book = BookFactory.getInstance("CODING").getBookNames(100);
		System.out.println(book.getId() + " " + book.getBookName() + " " + book.getPrice());
	}
}
